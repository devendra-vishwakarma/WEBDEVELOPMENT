import axios from 'axios';
import React, { useEffect, useState } from 'react'
import Header from './Header';
import ProductList from './ProductList';
import Category from './Category';

export default () => {
    const [productList, setProductList] = useState([]);
    useEffect(() => {
        axios.get("https://dummyjson.com/products")
            .then(response => {
                setProductList(response.data.productList);
            }).catch(err => {
                console.log(err);
            })
    }, []);
    return <>
        <Header />
        <Category />
        <ProductList productList={productList} />
    </>
}