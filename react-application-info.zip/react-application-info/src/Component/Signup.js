import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Signup() {
    // const [name, setName] = useState("");
    const [name, setName] = useState("");
    const [password, setPassword] = useState("");


    const signUp = () => {
        console.log(name + " aa gyaa data  " + password);
        axios.post("http://localhost:3001/admin/signup", { username: name, password }).then(response => {
            console.log(response.data)
            toast.success("SingUp Success")
        }).catch(err => {
            console.log(err)
            toast.error("SingUp failed")
        });
    }


    return <>
        <ToastContainer />
        <div className='box'>
            <div className='text-center py-5'>
                <img src={"infologo.png"} className='rounded-circle' style={{ height: '100px' }} /><span style={{ color: "aqua", fontSize: "2rem" }} className='ml-5'>InfoBeans-Foundation</span>
            </div>

            <div className='text-center' style={{ fontSize: "2rem", color: 'yellow' }}>Login</div>

            <div className='container boxeffect p-5 mt-5 d-flex justify-content-center align-item-center flex-column '>

                <div className='text-center mtm bg-primary mb-4 rounded-top rounded1'>
                    WELCOME
                </div>

                <form onSubmit={e => { e.preventDefault() }} className='d-flex justify-content-center align-item-center flex-column mb-5'>
                   
                    <div className="mb-3">
                        <label htmlFor="exampleInputEmail1" className="form-label">
                            Email address
                        </label>
                        <input
                            placeholder='enter your Email'
                            onChange={(e) => setName(e.target.value)}
                            type="text"
                            className="form-control"
                            id="exampleInputEmail1"
                            aria-describedby="emailHelp"
                        />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="exampleInputPassword1" className="form-label">
                            Password
                        </label>
                        <input
                            onChange={e => setPassword(e.target.value)}
                            placeholder='enter your password'
                            type="password"
                            className="form-control"
                            id="exampleInputPassword1"
                        />
                    </div>


                    <div>
                        <button onClick={signUp} type="submit" className="btn btn-primary mt-3">
                            SingUp
                        </button>
                        <span className='ml-5'><Link to={"/"}>Already have an account</Link></span>

                    </div>
                </form>
            </div>
        </div>
    </>
}

export default Signup