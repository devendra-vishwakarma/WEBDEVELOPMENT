import logo from './logo.svg';
import './App.css';
import { Route, Routes } from 'react-router-dom';
import Signup from './Component/Signup';
import Singin from './Component/Singin';
import Home from './Component/Home';
import Auth from './Component/Auth';

function App() {
   return <>
      <Routes>
         <Route path='/' element={<Singin/>} />
         <Route path='/SignUp' element={<Signup/>} />
         {/* <Route path='/home' element={<Auth><Home/></Auth>} /> */}
         <Route path='/home' element={<Home/>} />
      </Routes>
   </>
}

export default App;
